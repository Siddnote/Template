import { useState } from "react";
import { Container, Button, Form, FormGroup, Label, Input } from "reactstrap"
import { useNavigate } from "react-router";
function Login() {
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const navigate = useNavigate()
    return (
        <Container className="m-auto">
            <Form className='w-50'>
                <FormGroup >
                    <Label for="exampleEmail">Email</Label>
                    <Input type="email" name="email" id="exampleEmail" placeholder="with a placeholder" onChange={(e)=>setEmail(e.target.value)}/>
                </FormGroup>
                <FormGroup>
                    <Label for="examplePassword">Password</Label>
                    <Input type="password" name="password" id="examplePassword" placeholder="password placeholder" onChange={(e)=>setPassword(e.target.value)}/>
                </FormGroup>
                <Button className="" outline onClick={()=>navigate('/ShowCSV')
                }>Login</Button>
            </Form>
        </Container>
    );
}

export default Login;
