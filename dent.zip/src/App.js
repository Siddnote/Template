import { Routes, Route } from "react-router-dom"
import './App.css';
import CsvImport from "./CsvImport";
import Login from './Login';
import ShowCSV from "./ShowCsv";
function App() {
  return (
    <Routes>
   <Route path="/login" element={ <Login/> } />
   <Route path="/ShowCSV" element={ <ShowCSV/> } />
    </Routes>
  );
}

export default App;
