import React from "react";
import { Importer, ImporterField } from "react-csv-importer";

// theme CSS for React CSV Importer
import "react-csv-importer/dist/index.css";
import { useNavigate } from "react-router";
import { useState } from "react";
import { Modal, ModalHeader } from "reactstrap";
// basic styling and font for sandbox window

const CsvImport = ({ csvData, setCSVData,open,setOpen }) => {
  const navigate = useNavigate()
  return (
    <Modal isOpen={open} toggle={()=>setOpen((open)=>!open)}>
      <ModalHeader toggle={()=>setOpen((open)=>!open)}>Import File Here</ModalHeader>
      <Importer
        dataHandler={async (rows) => {
          // required, receives a list of parsed objects based on defined fields and user column mapping;
          // may be called several times if file is large
          // (if this callback returns a promise, the widget will wait for it before parsing more data)
          console.log("received batch of rows", rows);

          // mock timeout to simulate processing
          await new Promise((resolve) => setTimeout(resolve, 500));
        }}
        chunkSize={10000} // optional, internal parsing chunk size in bytes
        defaultNoHeader={false} // optional, keeps "data has headers" checkbox off by default
        restartable={false} // optional, lets user choose to upload another file when import is complete
        onStart={({ file, fields }) => {
          // optional, invoked when user has mapped columns and started import
          console.log("starting import of file", file, "with fields", fields);
        }}
        onComplete={({ file, fields }) => {
          // optional, invoked right after import is done (but user did not dismiss/reset the widget yet)

          console.log("finished import of file", file, "with fields", fields);
        }}
        onClose={() => {
          // optional, invoked when import is done and user clicked "Finish"
          // (if this is not specified, the widget lets the user upload another file)
          console.log("importer dismissed");
        }}
      >
        <ImporterField name="serial_number" label="Serial Number" />
        <ImporterField name="company_name" label="Company Name" />
        <ImporterField name="employee_markme" label="Employee Markme" optional />
        <ImporterField name="description" label="Description" optional />
        <ImporterField name="leave" label="Leave" optional />
      </Importer>
    </Modal>
  )
}
export default CsvImport
