import React, { useState } from 'react'
import DataTable from "react-data-table-component"
import Export from "react-data-table-component"
import { VscTrash, VscEdit } from "react-icons/vsc"
import { Button, Input, Label } from 'reactstrap';
import CsvImport from './CsvImport';

export default function Data({ }) {
  const [importer, setImporter] = useState(false)
  const TableHeader = () => {
    return (
      <>
        <div className='d-flex align-items-center w-100 justify-content-between'>
          <div className='d-flex justify-content-start flex-column'>
            <Input placeholder='Search' name="search" />
          </div>
          <div className='d-inline grid flex-column gap -3 justify-content-end'>
            <Button color='info' size='lg' onClick={() => setImporter(true)}>Import</Button>
            <Button color='primary' size='lg' className='mx-3' >Export</Button>
          </div>
        </div>
      </>
    )
  }
  const columns = [
    {
      name: 'Company Name',
      selector: row => row.company_name,
    },
    {
      name: 'Description',
      selector: row => row.description,
    },
    {
      name: 'Employee Markme',
      selector: row => row.employee_markme,
    },
    {
      name: 'Actions',
      maxWidth: "180px",
      selector: row => (
        <>
          <VscTrash size="15" color="red" className='me-3' />
          <VscEdit size={'15'} />
          <Button className='ms-3'>Send</Button>
        </>
      )
    }
  ];

  const data = [
    {
      "serial_number": "9788189999599",
      "company_name": "TALES OF SHIVA",
      "employee_markme": "Mark",
      "description": "mark",
      "leave": "0"
    },
    {
      "serial_number": "9780099578079",
      "company_name": "1Q84 THE COMPLETE TRILOGY",
      "employee_markme": "HARUKI MURAKAMI",
      "description": "Mark",
      "leave": "0"
    },
    {
      "serial_number": "9780198082897",
      "company_name": "MY KUMAN",
      "employee_markme": "Mark",
      "description": "Mark",
      "leave": "0"
    },
    {
      "serial_number": "9780007880331",
      "company_name": "THE GOD OF SMAAL THINGS",
      "employee_markme": "ARUNDHATI ROY",
      "description": "4TH HARPER COLLINS",
      "leave": "2"
    },
    {
      "serial_number": "9780545060455",
      "company_name": "THE BLACK CIRCLE",
      "employee_markme": "Mark",
      "description": "4TH HARPER COLLINS",
      "leave": "0"
    },
    {
      "serial_number": "9788126525072",
      "company_name": "THE THREE LAWS OF PERFORMANCE",
      "employee_markme": "Mark",
      "description": "4TH HARPER COLLINS",
      "leave": "0"
    },
    {
      "serial_number": "9789381626610",
      "company_name": "CHAMarkKYA MANTRA",
      "employee_markme": "Mark",
      "description": "4TH HARPER COLLINS",
      "leave": "0"
    },
    {
      "serial_number": "9788184513523",
      "company_name": "59.FLAGS",
      "employee_markme": "Mark",
      "description": "4TH HARPER COLLINS",
      "leave": "0"
    },
    {
      "serial_number": "9780743234801",
      "company_name": "THE POWER OF POSITIVE THINKING FROM",
      "employee_markme": "Mark",
      "description": "A & A PUBLISHER",
      "leave": "0"
    },
    {
      "serial_number": "9789381529621",
      "company_name": "YOU CAN IF YO THINK YO CAN",
      "employee_markme": "PEALE",
      "description": "A & A PUBLISHER",
      "leave": "0"
    },
    {
      "serial_number": "9788183223966",
      "company_name": "DONGRI SE DUBAI TAK (MPH)",
      "employee_markme": "Mark",
      "description": "A & A PUBLISHER",
      "leave": "0"
    },
    {
      "serial_number": "9788187776005",
      "company_name": "MarkLANDA ADYTAN KOSH",
      "employee_markme": "Mark",
      "description": "AADISH BOOK DEPOT",
      "leave": "0"
    },
    {
      "serial_number": "9788187776013",
      "company_name": "MarkLANDA VISHAL SHABD SAGAR",
      "employee_markme": "-",
      "description": "AADISH BOOK DEPOT",
      "leave": "1"
    },
    {
      "serial_number": "8187776021",
      "company_name": "MarkLANDA CONCISE DICT(ENG TO HINDI)",
      "employee_markme": "Mark",
      "description": "AADISH BOOK DEPOT",
      "leave": "0"
    },
    {
      "serial_number": "9789384716165",
      "company_name": "LIEUTEMarkMarkT GENERAL BHAGAT: A SAGA OF BRAVERY AND LEADERSHIP",
      "employee_markme": "Mark",
      "description": "AAM COMICS",
      "leave": "2"
    },
    {
      "serial_number": "9789384716233",
      "company_name": "LN. MarkIK SUNDER SINGH",
      "employee_markme": "N.A",
      "description": "AAN COMICS",
      "leave": "0"
    },
    {
      "serial_number": "9789384850319",
      "company_name": "I AM KRISHMark",
      "employee_markme": "DEEP TRIVEDI",
      "description": "AATMAN INNOVATIONS PVT LTD",
      "leave": "1"
    },
    {
      "serial_number": "9789384850357",
      "company_name": "DON'T TEACH ME TOLERANCE INDIA",
      "employee_markme": "DEEP TRIVEDI",
      "description": "AATMAN INNOVATIONS PVT LTD",
      "leave": "0"
    },
    {
      "serial_number": "9789384850364",
      "company_name": "MUJHE SAHISHNUTA MAT SIKHAO BHARAT",
      "employee_markme": "DEEP TRIVEDI",
      "description": "AATMAN INNOVATIONS PVT LTD",
      "leave": "0"
    },
    {
      "serial_number": "9789384850746",
      "company_name": "SECRETS OF DESTINY",
      "employee_markme": "DEEP TRIVEDI",
      "description": "AATMAN INNOVATIONS PVT LTD",
      "leave": "1"
    },
    {
      "serial_number": "9789384850753",
      "company_name": "BHAGYA KE RAHASYA (HINDI) SECRET OF DESTINY",
      "employee_markme": "DEEP TRIVEDI",
      "description": "AATMAN INNOVATIONS PVT LTD",
      "leave": "1"
    },
    {
      "serial_number": "9788192669038",
      "company_name": "MEIN MANN HOON",
      "employee_markme": "DEEP TRIVEDI",
      "description": "AATMAN INNOVATIONS PVT LTD",
      "leave": "0"
    },
    {
      "serial_number": "9789384850098",
      "company_name": "I AM THE MIND",
      "employee_markme": "DEEP TRIVEDI",
      "description": "AATMARAM & SONS",
      "leave": "0"
    },
    {
      "serial_number": "9780349121420",
      "company_name": "THE ART OF CHOOSING",
      "employee_markme": "SHEEMark IYENGAR",
      "description": "ABACUS",
      "leave": "0"
    },
    {
      "serial_number": "9780349123462",
      "company_name": "IN SPITE OF THE GODS",
      "employee_markme": "EDWARD LUCE",
      "description": "ABACUS",
      "leave": "1"
    },
    {
      "serial_number": "9788188440061",
      "company_name": "QUESTIONS & ANWERS ABOUT THE GREAT BIBLE",
      "employee_markme": "Mark",
      "description": "ABC PUBLISHERS DISTRIBUTORS",
      "leave": "4"
    },
    {
      "serial_number": "9789382088189",
      "company_name": "NIBANDH EVAM KAHANI LEKHAN { HINDI }",
      "employee_markme": "Mark",
      "description": "ABHI BOOKS",
      "leave": "1"
    },
    {
      "serial_number": "9789332703759",
      "company_name": "INDIAN ECONOMY SINCE INDEPENDENCE 27TH /E",
      "employee_markme": "UMA KAPILA",
      "description": "ACADEMIC FOUNDATION",
      "leave": "1"
    },
    {
      "serial_number": "9788171888016",
      "company_name": "ECONOMIC DEVELOPMENT AND POLICY IN INDIA",
      "employee_markme": "UMA KAPILA",
      "description": "ACADEMIC FOUNDATION",
      "leave": "1"
    },
    {
      "serial_number": "9789332704343",
      "company_name": "INDIAN ECONOMY PERFORMANCE 18TH/E  2017-2018",
      "employee_markme": "UMA KAPILA",
      "description": "ACADEMIC FOUNDATION",
      "leave": "2"
    },
    {
      "serial_number": "9789332703735",
      "company_name": "INDIAN ECONOMIC DEVELOPMENTSINCE 1947 (NO RETURMarkBLE)",
      "employee_markme": "UMA KAPILA",
      "description": "ACADEMIC FOUNDATION",
      "leave": "1"
    },
    {
      "serial_number": "9789383454143",
      "company_name": "PRELIMS SPECIAL READING COMPREHENSION PAPER II CSAT",
      "employee_markme": "MarkGENDRA PRATAP",
      "description": "ACCESS PUBLISHING INDIA PVT.LTD",
      "leave": "0"
    },
    {
      "serial_number": "9789383454204",
      "company_name": "THE CONSTITUTION OF INDIA 2ND / E",
      "employee_markme": "AR KHAN",
      "description": "ACCESS PUBLISHING INDIA PVT.LTD",
      "leave": "10"
    },
    {
      "serial_number": "9789386361011",
      "company_name": "INDIAN HERITAGE ,ART & CULTURE",
      "employee_markme": "MADHUKAR",
      "description": "ACCESS PUBLISHING INDIA PVT.LTD",
      "leave": "10"
    },
    {
      "serial_number": "9789383454303",
      "company_name": "BHARAT KA SAMVIDHAN",
      "employee_markme": "AR KHAN",
      "description": "ACCESS PUBLISHING INDIA PVT.LTD",
      "leave": "4"
    },
    {
      "serial_number": "9789383454471",
      "company_name": "ETHICS, INTEGRITY & APTITUDE ( 3RD/E)",
      "employee_markme": "P N ROY ,G SUBBA RAO",
      "description": "ACCESS PUBLISHING INDIA PVT.LTD",
      "leave": "10"
    },
    {
      "serial_number": "9789383454563",
      "company_name": "GENERAL STUDIES PAPER -- I (2016)",
      "employee_markme": "Mark",
      "description": "ACCESS PUBLISHING INDIA PVT.LTD",
      "leave": "0"
    },
    {
      "serial_number": "9789383454570",
      "company_name": "GENERAL STUDIES PAPER - II (2016)",
      "employee_markme": "Mark",
      "description": "ACCESS PUBLISHING INDIA PVT.LTD",
      "leave": "0"
    },
    {
      "serial_number": "9789383454693",
      "company_name": "INDIAN AND WORLD GEOGRAPHY 2E",
      "employee_markme": "D R KHULLAR",
      "description": "ACCESS PUBLISHING INDIA PVT.LTD",
      "leave": "10"
    },
    {
      "serial_number": "9789383454709",
      "company_name": "VASTUNISTHA PRASHN SANGRAHA: BHARAT KA ITIHAS",
      "employee_markme": "MEEMarkKSHI KANT",
      "description": "ACCESS PUBLISHING INDIA PVT.LTD",
      "leave": "0"
    },
    {
      "serial_number": "9789383454723",
      "company_name": "PHYSICAL, HUMAN AND ECONOMIC GEOGRAPHY",
      "employee_markme": "D R KHULLAR",
      "description": "ACCESS PUBLISHING INDIA PVT.LTD",
      "leave": "4"
    },
    {
      "serial_number": "9789383454730",
      "company_name": "WORLD GEOGRAPHY",
      "employee_markme": "DR KHULLAR",
      "description": "ACCESS PUBLISHING INDIA PVT.LTD",
      "leave": "5"
    },
    {
      "serial_number": "9789383454822",
      "company_name": "INDIA: MAP ENTRIES IN GEOGRAPHY",
      "employee_markme": "MAJID HUSAIN",
      "description": "ACCESS PUBLISHING INDIA PVT.LTD",
      "leave": "5"
    },
    {
      "serial_number": "9789383454853",
      "company_name": "GOOD GOVERMarkNCE IN INDIA 2/ED.",
      "employee_markme": "G SUBBA RAO",
      "description": "ACCESS PUBLISHING INDIA PVT.LTD",
      "leave": "1"
    },
    {
      "serial_number": "9789383454884",
      "company_name": "KAMYABI KE SUTRA-CIVIL SEWA PARIKSHA AAP KI MUTTHI MEIN",
      "employee_markme": "ASHOK KUMAR",
      "description": "ACCESS PUBLISHING INDIA PVT.LTD",
      "leave": "0"
    },
    {
      "serial_number": "9789383454891",
      "company_name": "GENERAL SCIENCE PRELIRY EXAM",
      "employee_markme": "Mark",
      "description": "ACCESS PUBLISHING INDIA PVT.LTD",
      "leave": "0"
    },
    {
      "serial_number": "9781742860190",
      "company_name": "SUCCESS AND DYSLEXIA",
      "employee_markme": "SUCCESS AND DYSLEXIA",
      "description": "ACER PRESS",
      "leave": "0"
    },
    {
      "serial_number": "9781742860114",
      "company_name": "AN EXTRAORDIMarkRY SCHOOL",
      "employee_markme": "SARA JAMES",
      "description": "ACER PRESS",
      "leave": "0"
    },
    {
      "serial_number": "9781742861463",
      "company_name": "POWERFUL PRACTICES FOR READING IMPROVEMENT",
      "employee_markme": "GLASSWELL",
      "description": "ACER PRESS",
      "leave": "0"
    },
    {
      "serial_number": "9781742862859",
      "company_name": "EARLY CHILDHOOD PLAY MATTERS",
      "employee_markme": "SHOMark BASS",
      "description": "ACER PRESS",
      "leave": "0"
    },
    {
      "serial_number": "9781742863641",
      "company_name": "LEADING LEARNING AND TEACHING",
      "employee_markme": "STEPHEN DINHAM",
      "description": "ACER PRESS",
      "leave": "0"
    },
    {
      "serial_number": "9781742863658",
      "company_name": "READING AND LEARNING DIFFICULTIES",
      "employee_markme": "PETER WESTWOOD",
      "description": "ACER PRESS",
      "leave": "0"
    },
    {
      "serial_number": "9781742863665",
      "company_name": "NUMERACY AND LEARNING DIFFICULTIES",
      "employee_markme": "PETER WOODLAND]",
      "description": "ACER PRESS",
      "leave": "0"
    },
    {
      "serial_number": "9781742863771",
      "company_name": "TEACHING AND LEARNING DIFFICULTIES",
      "employee_markme": "PETER WOODLAND",
      "description": "ACER PRESS",
      "leave": "0"
    },
    {
      "serial_number": "9781742861678",
      "company_name": "USING DATA TO IMPROVE LEARNING",
      "employee_markme": "ANTHONY SHADDOCK",
      "description": "ACER PRESS",
      "leave": "0"
    },
    {
      "serial_number": "9781742862484",
      "company_name": "PATHWAYS TO SCHOOL SYSTEM IMPROVEMENT",
      "employee_markme": "MICHAEL GAFFNEY",
      "description": "ACER PRESS",
      "leave": "0"
    },
    {
      "serial_number": "9781742860176",
      "company_name": "FOR THOSE WHO TEACH",
      "employee_markme": "PHIL RIDDEN",
      "description": "ACER PRESS",
      "leave": "0"
    },
    {
      "serial_number": "9781742860213",
      "company_name": "KEYS TO SCHOOL LEADERSHIP",
      "employee_markme": "PHIL RIDDEN & JOHN DE NOBILE",
      "description": "ACER PRESS",
      "leave": "0"
    },
    {
      "serial_number": "9781742860220",
      "company_name": "DIVERSE LITERACIES IN EARLY CHILDHOOD",
      "employee_markme": "LEONIE ARTHUR",
      "description": "ACER PRESS",
      "leave": "0"
    },
    {
      "serial_number": "9781742860237",
      "company_name": "CREATIVE ARTS IN THE LIVESOF YOUNG CHILDREN",
      "employee_markme": "ROBYN EWING",
      "description": "ACER PRESS",
      "leave": "0"
    },
    {
      "serial_number": "9781742860336",
      "company_name": "SOCIAL AND EMOTIOMarkL DEVELOPMENT",
      "employee_markme": "ROS LEYDEN AND ERIN SHALE",
      "description": "ACER PRESS",
      "leave": "0"
    },
    {
      "serial_number": "9781742860343",
      "company_name": "DISCUSSIONS IN SCIENCE",
      "employee_markme": "TIM SPROD",
      "description": "ACER PRESS",
      "leave": "0"
    },
    {
      "serial_number": "9781742860404",
      "company_name": "YOUNG CHILDREN LEARNING MATHEMATICS",
      "employee_markme": "ROBERT HUNTING",
      "description": "ACER PRESS",
      "leave": "0"
    },
    {
      "serial_number": "9781742860626",
      "company_name": "COACHING CHILDREN",
      "employee_markme": "KELLY SUMICH",
      "description": "ACER PRESS",
      "leave": "1"
    },
    {
      "serial_number": "9781742860923",
      "company_name": "TEACHING PHYSICAL EDUCATIOMarkL IN PRIMARY SCHOOL",
      "employee_markme": "JANET L CURRIE",
      "description": "ACER PRESS",
      "leave": "0"
    },
    {
      "serial_number": "9781742861111",
      "company_name": "ASSESSMENT AND REPORTING",
      "employee_markme": "PHIL RIDDEN AND SANDY",
      "description": "ACER PRESS",
      "leave": "0"
    },
    {
      "serial_number": "9781742861302",
      "company_name": "COLLABORATION IN LEARNING",
      "employee_markme": "MAL LEE AND LORRAE WARD",
      "description": "ACER PRESS",
      "leave": "0"
    },
    {
      "serial_number": "9780864315250",
      "company_name": "RE-IMAGINING EDUCATIMarkL LEADERSHIP",
      "employee_markme": "BRIAN J.CALDWELL",
      "description": "ACER PRESS",
      "leave": "0"
    },
    {
      "serial_number": "9780864317025",
      "company_name": "TOWARDS A MOVING SCHOOL",
      "employee_markme": "FLEMING & KLEINHENZ",
      "description": "ACER PRESS",
      "leave": "0"
    },
    {
      "serial_number": "9780864317230",
      "company_name": "DESINGNING A THINKING A CURRICULAM",
      "employee_markme": "SUSAN WILKS",
      "description": "ACER PRESS",
      "leave": "0"
    },
    {
      "serial_number": "9780864318961",
      "company_name": "LEADING A DIGITAL SCHOOL",
      "employee_markme": "MAL LEE AND MICHEAL GAFFNEY",
      "description": "ACER PRESS",
      "leave": "0"
    },
    {
      "serial_number": "9780864319043",
      "company_name": "NUMERACY",
      "employee_markme": "WESTWOOD",
      "description": "ACER PRESS",
      "leave": "0"
    },
    {
      "serial_number": "9780864319203",
      "company_name": "TEACHING ORAL LANGUAGE",
      "employee_markme": "JOHN MUNRO",
      "description": "ACER PRESS",
      "leave": "0"
    },
    {
      "serial_number": "9780864319449",
      "company_name": "SPELLING",
      "employee_markme": "WESTWOOD",
      "description": "ACER PRESS",
      "leave": "0"
    },
    {
      "serial_number": "9788189999803",
      "company_name": "STORIES OF SHIVA",
      "employee_markme": "Mark",
      "description": "ACK",
      "leave": "0"
    },
    {
      "serial_number": "9788189999988",
      "company_name": "JAMSET  JI TATA: THE MAN WHO SAW TOMORROW",
      "employee_markme": "",
      "description": "ACK",
      "leave": "0"
    },
    {
      "serial_number": "9788184820355",
      "company_name": "HEROES FROM THE MAHABHARTA { 5-IN-1 }",
      "employee_markme": "Mark",
      "description": "ACK",
      "leave": "0"
    },
    {
      "serial_number": "9788184820553",
      "company_name": "SURYA",
      "employee_markme": "",
      "description": "ACK",
      "leave": "0"
    },
    {
      "serial_number": "9788184820645",
      "company_name": "TALES OF THE MOTHER GODDESS",
      "employee_markme": "-",
      "description": "ACK",
      "leave": "0"
    },
    {
      "serial_number": "9788184820652",
      "company_name": "ADVENTURES OF KRISHMark",
      "employee_markme": "Mark",
      "description": "ACK",
      "leave": "0"
    },
    {
      "serial_number": "9788184822113",
      "company_name": "MAHATMA GANDHI",
      "employee_markme": "Mark",
      "description": "ACK",
      "leave": "1"
    },
    {
      "serial_number": "9788184822120",
      "company_name": "TALES FROM THE PANCHATANTRA 3-IN-1",
      "employee_markme": "-",
      "description": "ACK",
      "leave": "0"
    },
    {
      "serial_number": "9788184821482",
      "company_name": "YET MORE TALES FROM THE JATAKAS { 3-IN-1 }",
      "employee_markme": "AMarkNT PAI",
      "description": "ACK",
      "leave": "0"
    },
    {
      "serial_number": "9788184825763",
      "company_name": "LEGENDARY RULERS OF INDIA",
      "employee_markme": "-",
      "description": "ACK",
      "leave": "0"
    },
    {
      "serial_number": "9788184825862",
      "company_name": "GREAT INDIAN CLASSIC",
      "employee_markme": "Mark",
      "description": "ACK",
      "leave": "0"
    },
    {
      "serial_number": "9788184823219",
      "company_name": "TULSIDAS ' RAMAYAMark",
      "employee_markme": "Mark",
      "description": "ACK",
      "leave": "0"
    },
    {
      "serial_number": "9788184820782",
      "company_name": "TALES OF HANUMAN",
      "employee_markme": "-",
      "description": "ACK",
      "leave": "0"
    },
    {
      "serial_number": "9788184820089",
      "company_name": "VALMIKI'S RAMAYAMark",
      "employee_markme": "A C K",
      "description": "ACK",
      "leave": "1"
    },
    {
      "serial_number": "9788184825213",
      "company_name": "THE BEST OF INIDAN WIT AND WISDOM",
      "employee_markme": "Mark",
      "description": "ACK",
      "leave": "0"
    },
    {
      "serial_number": "9788184820997",
      "company_name": "MORE TALES FROM THE PANCHTANTRA",
      "employee_markme": "AMarkNT PAL",
      "description": "ACK",
      "leave": "0"
    },
    {
      "serial_number": "9788184824018",
      "company_name": "THE GREAT MUGHALS {5-IN-1}",
      "employee_markme": "AMarkNT.",
      "description": "ACK",
      "leave": "0"
    },
    {
      "serial_number": "9788184824049",
      "company_name": "FAMOUS SCIENTISTS",
      "employee_markme": "Mark",
      "description": "ACK",
      "leave": "0"
    },
    {
      "serial_number": "9788184825978",
      "company_name": "KOMarkRK",
      "employee_markme": "Mark",
      "description": "ACK",
      "leave": "0"
    },
    {
      "serial_number": "9788184826098",
      "company_name": "THE MUGHAL COURT",
      "employee_markme": "REEMark",
      "description": "ACK",
      "leave": "0"
    },
    {
      "serial_number": "9788184821536",
      "company_name": "MORE STORIES FROM THE JATAKAS",
      "employee_markme": "Mark",
      "description": "ACK",
      "leave": "0"
    },
    {
      "serial_number": "9788184821543",
      "company_name": "MORE TALES OF BIRBAL",
      "employee_markme": "-",
      "description": "ACK",
      "leave": "0"
    },
    {
      "serial_number": "9788184821550",
      "company_name": "TALES FROM THE JATAKAS",
      "employee_markme": "-",
      "description": "ACK",
      "leave": "0"
    },
    {
      "serial_number": "9788184821567",
      "company_name": "RAMarkS OF MEWAR",
      "employee_markme": "-",
      "description": "ACK",
      "leave": "0"
    },
    {
      "serial_number": "9788184821574",
      "company_name": "THE SONS OF THE PANDAVAS",
      "employee_markme": "-",
      "description": "ACK",
      "leave": "0"
    }
  ]
  // const actionsMemo = React.useMemo(() => <Export onExport={() => console.log(data)} />, []);


  return (
    <div>
      <DataTable
        data={data}
        columns={columns}
        selectableRows
        // actions={actionsMemo}
        subHeader
        subHeaderComponent={<TableHeader />}
        pagination

      />
      <CsvImport open={importer} setOpen={setImporter} />
    </div>
  )
}
