import DataTable from "./Data" 
import { useLocation } from 'react-router';
import CsvImport from './CsvImport';
import { useState } from 'react';
import Data from "./Data";
const ShowCSV=({...props})=>{

    return(
        <>
          <header className='d-flex justify-content-center my-3'>
            Import CSV
          </header>
          <Data/>
        </>
    )

}
export default ShowCSV